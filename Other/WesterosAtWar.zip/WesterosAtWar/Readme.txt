Two ways to run this project.

I way:-
(Require tomcat server and MySQL installed)
1. Restore the backup to mysql application.
2. Place WesterosAtWar.war to "webapps" folder in "apache-tomcat" installation directory.
3. Run the server
4. Change the user name and password for MySQL from config.properties file.
5. Run project in local host.

II way:-
(Require eclipse and tomcat Already Set)
1. Restore the project from Source code directory.
2. Change the user name and password for MySQL from config.properties file located in com.properties package.
3. Run the project. 